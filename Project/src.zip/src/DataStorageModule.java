import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores crawl results in memory and exports to CSV and JSON files.
 * Supports incremental flushing to prevent data loss on crashes.
 */
public class DataStorageModule {

    /**
     * Immutable record holding data for one crawled page.
     */
    public static class CrawlResult {
        public final String url;
        public final String title;
        /** The URL that discovered this page. Null for the seed (root) node. */
        public final String parentUrl;
        public final int depth;
        public final long fetchTimeMs;
        public final boolean keywordMatch;
        public final long timestamp;

        /**
         * @param url          the crawled page URL
         * @param title        the page <title> tag content
         * @param parentUrl    the URL that linked to this page; null for the seed
         * @param depth        BFS depth at which this page was discovered
         * @param fetchTimeMs  milliseconds taken to fetch the page
         * @param keywordMatch true if the keyword was found in title or body
         */
        public CrawlResult(String url, String title, String parentUrl, int depth, long fetchTimeMs, boolean keywordMatch) {
            this.url = url;
            this.title = title;
            this.parentUrl = parentUrl;
            this.depth = depth;
            this.fetchTimeMs = fetchTimeMs;
            this.keywordMatch = keywordMatch;
            this.timestamp = System.currentTimeMillis();
        }
    }

    private static final int FLUSH_INTERVAL = 50;
    private static final String OUTPUT_DIR = "crawl_output";

    private final List<CrawlResult> results;
    /** Per-URL extracted page text — served via GET /api/page for the node data popup (F-12). */
    private final ConcurrentHashMap<String, String> pageTextCache;
    private String sessionId;
    private int lastFlushedCsvIndex;
    private int lastFlushedJsonIndex;
    private boolean flushed;

    public DataStorageModule() {
        this.results       = new ArrayList<>();
        this.pageTextCache = new ConcurrentHashMap<>();
        this.sessionId = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        this.lastFlushedCsvIndex = 0;
        this.lastFlushedJsonIndex = 0;

        java.io.File dir = new java.io.File(OUTPUT_DIR);
        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                System.err.println("[WARN] Could not create output directory: " + OUTPUT_DIR);
            }
        }
    }

    /**
     * Resets the storage for a new crawl session.
     */
    public void clear() {
        synchronized (results) {
            results.clear();
            sessionId = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            lastFlushedCsvIndex = 0;
            lastFlushedJsonIndex = 0;
            flushed = false;
        }
        pageTextCache.clear();
    }

    /**
     * Stores extracted page text for a URL (F-12).
     * Called by CrawlEngine immediately after a successful fetch.
     * Safe to call from any thread — ConcurrentHashMap handles concurrency.
     */
    public void storePageText(String url, String text) {
        if (url == null || url.isBlank() || text == null) return;
        // Cap individual entry at 64KB to prevent heap pressure on huge pages
        if (text.length() > 65536) {
            text = text.substring(0, 65536) + "\n[...truncated at 64 KB]";
        }
        pageTextCache.put(url, text);
    }

    /**
     * Returns stored page text for the given URL, or null if not cached (F-12).
     */
    public String getPageText(String url) {
        if (url == null) return null;
        return pageTextCache.get(url);
    }

    /**
     * Adds a result to the in-memory buffer.
     * Triggers an incremental flush every FLUSH_INTERVAL pages.
     */
    public void addResult(CrawlResult result) {
        results.add(result);
        if (results.size() % FLUSH_INTERVAL == 0) {
            flushIncrementalCSV();
            flushIncrementalJSON();
        }
    }

    /**
     * Returns an unmodifiable view of all results collected so far.
     */
    public List<CrawlResult> getAllResults() {
        return Collections.unmodifiableList(results);
    }

    /**
     * Returns the total number of results stored.
     */
    public int getResultCount() {
        return results.size();
    }

    /**
     * Writes all results to both CSV and JSON files.
     * Guarded to prevent double-export from shutdown hook.
     */
    public void flush() {
        if (results.isEmpty() || flushed) {
            return;
        }
        flushed = true;
        exportCSV();
        exportJSON();
        exportGraphJSON();
    }

    /**
     * Produces a Cytoscape.js-compliant JSON string for the /api/graph endpoint.
     * Thread-safe: synchronized on the results list to prevent
     * ConcurrentModificationException if the crawler adds results while
     * the HTTP server reads them.
     *
     * Output format:
     *   {
     *     "nodes": [ { "data": { "id": "url", "label": "title", "depth": 0, ... } } ],
     *     "edges": [ { "data": { "id": "e0", "source": "parentUrl", "target": "url" } } ]
     *   }
     *
     * @return JSON string safe for direct HTTP response
     */
    public String getGraphJson() {
        synchronized (results) {
            if (results.isEmpty()) {
                return "{\"nodes\":[],\"edges\":[]}"; 
            }

            StringBuilder sb = new StringBuilder(results.size() * 150);
            sb.append("{\n");
            sb.append("  \"nodes\": [\n");

            for (int i = 0; i < results.size(); i++) {
                CrawlResult r = results.get(i);
                sb.append("    {\"data\": {");
                sb.append("\"id\": ").append(escapeJSON(r.url)).append(", ");
                sb.append("\"label\": ").append(escapeJSON(r.title != null ? r.title : r.url)).append(", ");
                sb.append("\"depth\": ").append(r.depth).append(", ");
                sb.append("\"fetchTimeMs\": ").append(r.fetchTimeMs).append(", ");
                sb.append("\"keywordMatch\": ").append(r.keywordMatch).append(", ");
                sb.append("\"timestamp\": ").append(r.timestamp);
                sb.append("}}");
                if (i < results.size() - 1) sb.append(",");
                sb.append("\n");
            }

            sb.append("  ],\n");
            sb.append("  \"edges\": [\n");

            int edgeId = 0;
            boolean firstEdge = true;
            for (CrawlResult r : results) {
                // Only create an edge if this node has a known parent
                if (r.parentUrl != null && !r.parentUrl.isBlank()) {
                    if (!firstEdge) sb.append(",\n");
                    sb.append("    {\"data\": {");
                    sb.append("\"id\": \"e").append(edgeId++).append("\", ");
                    sb.append("\"source\": ").append(escapeJSON(r.parentUrl)).append(", ");
                    sb.append("\"target\": ").append(escapeJSON(r.url));
                    sb.append("}}");
                    firstEdge = false;
                }
            }

            sb.append("\n  ]\n}");
            return sb.toString();
        }
    }

    /**
     * Writes the Cytoscape-compliant graph JSON to disk at session end.
     * This complements getGraphJson() which serves the live HTTP endpoint.
     */
    private void exportGraphJSON() {
        String filename = OUTPUT_DIR + "/crawl_" + sessionId + "_graph.json";
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, false))) {
            writer.print(getGraphJson());
            System.out.println("[EXPORT] Graph JSON saved: " + filename);
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to write graph JSON: " + e.getMessage());
        }
    }

    /**
     * Exports all results to a CSV file.
     */
    private void exportCSV() {
        String filename = OUTPUT_DIR + "/crawl_" + sessionId + ".csv";
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, false))) {
            writer.println("URL,Title,ParentURL,Depth,FetchTime_ms,KeywordMatch,Timestamp");

            for (CrawlResult r : results) {
                writer.println(
                    escapeCSV(r.url) + ","
                    + escapeCSV(r.title) + ","
                    + escapeCSV(r.parentUrl) + ","
                    + r.depth + ","
                    + r.fetchTimeMs + ","
                    + r.keywordMatch + ","
                    + r.timestamp
                );
            }

            System.out.println("[EXPORT] CSV saved: " + filename + " (" + results.size() + " rows)");
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to write CSV: " + e.getMessage());
        }
    }

    /**
     * Appends only new results since the last flush to the CSV file.
     * This prevents data loss if the crawl crashes mid-session.
     */
    private void flushIncrementalCSV() {
        String filename = OUTPUT_DIR + "/crawl_" + sessionId + "_partial.csv";
        boolean isNewFile = (lastFlushedCsvIndex == 0);

        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, true))) {
            if (isNewFile) {
                writer.println("URL,Title,ParentURL,Depth,FetchTime_ms,KeywordMatch,Timestamp");
            }

            for (int i = lastFlushedCsvIndex; i < results.size(); i++) {
                CrawlResult r = results.get(i);
                writer.println(
                    escapeCSV(r.url) + ","
                    + escapeCSV(r.title) + ","
                    + escapeCSV(r.parentUrl) + ","
                    + r.depth + ","
                    + r.fetchTimeMs + ","
                    + r.keywordMatch + ","
                    + r.timestamp
                );
            }

            lastFlushedCsvIndex = results.size();
        } catch (IOException e) {
            System.err.println("[ERROR] Incremental CSV flush failed: " + e.getMessage());
        }
    }

    private void flushIncrementalJSON() {
        String filename = OUTPUT_DIR + "/crawl_" + sessionId + "_partial.json";

        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, true))) {
            for (int i = lastFlushedJsonIndex; i < results.size(); i++) {
                CrawlResult r = results.get(i);
                writer.println("  {");
                writer.println("    \"url\": " + escapeJSON(r.url) + ",");
                writer.println("    \"title\": " + escapeJSON(r.title) + ",");
                writer.println("    \"parentUrl\": " + escapeJSON(r.parentUrl) + ",");
                writer.println("    \"depth\": " + r.depth + ",");
                writer.println("    \"fetchTimeMs\": " + r.fetchTimeMs + ",");
                writer.println("    \"keywordMatch\": " + r.keywordMatch + ",");
                writer.println("    \"timestamp\": " + r.timestamp);
                writer.println("  },");
            }
            lastFlushedJsonIndex = results.size();
        } catch (IOException e) {
            System.err.println("[ERROR] Incremental JSON flush failed: " + e.getMessage());
        }
    }

    /**
     * Exports all results to a JSON file.
     */
    private void exportJSON() {
        String filename = OUTPUT_DIR + "/crawl_" + sessionId + ".json";
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, false))) {
            writer.println("{");
            writer.println("  \"crawlSession\": {");
            writer.println("    \"sessionId\": \"" + sessionId + "\",");
            writer.println("    \"totalPages\": " + results.size() + ",");
            writer.println("    \"exportedAt\": \"" + LocalDateTime.now() + "\"");
            writer.println("  },");
            writer.println("  \"results\": [");

            for (int i = 0; i < results.size(); i++) {
                CrawlResult r = results.get(i);
                String comma = (i < results.size() - 1) ? "," : "";
                writer.println("    {");
                writer.println("      \"url\": " + escapeJSON(r.url) + ",");
                writer.println("      \"title\": " + escapeJSON(r.title) + ",");
                writer.println("      \"parentUrl\": " + escapeJSON(r.parentUrl) + ",");
                writer.println("      \"depth\": " + r.depth + ",");
                writer.println("      \"fetchTimeMs\": " + r.fetchTimeMs + ",");
                writer.println("      \"keywordMatch\": " + r.keywordMatch + ",");
                writer.println("      \"timestamp\": " + r.timestamp);
                writer.println("    }" + comma);
            }

            writer.println("  ]");
            writer.println("}");

            System.out.println("[EXPORT] JSON saved: " + filename + " (" + results.size() + " entries)");
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to write JSON: " + e.getMessage());
        }
    }

    /**
     * Escapes a field value for CSV. Wraps in quotes if the value
     * contains commas, quotes, or newlines.
     */
    private static String escapeCSV(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    /**
     * Escapes a string for JSON. Wraps in quotes and escapes
     * special characters.
     */
    private static String escapeJSON(String value) {
        if (value == null) return "null";
        String escaped = value.replace("\\", "\\\\")
                              .replace("\"", "\\\"")
                              .replace("\n", "\\n")
                              .replace("\r", "\\r")
                              .replace("\t", "\\t");
        StringBuilder sb = new StringBuilder(escaped);
        for (int i = 0; i < sb.length(); i++) {
            char c = sb.charAt(i);
            if (c < 0x20 && c != '\n' && c != '\r' && c != '\t') {
                String replacement = String.format("\\u%04x", (int) c);
                sb.replace(i, i + 1, replacement);
                i += replacement.length() - 1;
            }
        }
        return "\"" + sb + "\"";
    }
}
