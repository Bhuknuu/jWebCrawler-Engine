import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HTTPFetcherHTMLParser {

    private static final int CONNECTION_TIMEOUT_MS = 8000;
    private static final int READ_TIMEOUT_MS       = 15000;
    private static final int MAX_BODY_SIZE         = 1_048_576;
    private static final int MAX_REDIRECTS         = 5;
    private static final String USER_AGENT         = "jWebCrawler/1.0 (+educational project)";

    // H-01: captures href (group 1), then the full anchor tag close so we can grab text separately
    private static final Pattern ANCHOR_PATTERN = Pattern.compile(
        "<a\\s+[^>]*?href\\s*=\\s*[\"']\\s*([^\"'\\s][^\"']*?)\\s*[\"'][^>]*>(.*?)</a>",
        Pattern.CASE_INSENSITIVE | Pattern.DOTALL
    );

    private static final Pattern TITLE_PATTERN = Pattern.compile(
        "<title[^>]*>([^<]*)</title>",
        Pattern.CASE_INSENSITIVE
    );

    // H-03: numeric entity patterns (decimal and hex)
    private static final Pattern ENTITY_DECIMAL = Pattern.compile("&#(\\d+);");
    private static final Pattern ENTITY_HEX     = Pattern.compile("&#x([0-9a-fA-F]+);");

    // H-02 / H-04: charset pattern for Content-Type parsing
    private static final Pattern CHARSET_PATTERN = Pattern.compile(
        "charset=([\\w-]+)", Pattern.CASE_INSENSITIVE
    );

    public static final class LinkWithText {
        public final String url;
        public final String anchorText;

        LinkWithText(String url, String anchorText) {
            this.url        = url;
            this.anchorText = anchorText;
        }
    }

    // H-04: opens a single connection without following cross-scheme redirects
    private HttpURLConnection openConnection(String urlString) throws IOException {
        URL url = URI.create(urlString).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(CONNECTION_TIMEOUT_MS);
        conn.setReadTimeout(READ_TIMEOUT_MS);
        conn.setRequestProperty("User-Agent", USER_AGENT);
        conn.setRequestProperty("Accept", "text/html,application/xhtml+xml");
        conn.setInstanceFollowRedirects(false); // manual loop handles cross-scheme
        return conn;
    }

    public String fetchPage(String urlString) {
        HttpURLConnection connection = null;
        try {
            // H-04: manual redirect loop to handle HTTP → HTTPS
            String currentUrl = urlString;
            for (int redirects = 0; redirects < MAX_REDIRECTS; redirects++) {
                connection = openConnection(currentUrl);
                int status = connection.getResponseCode();

                if (status == HttpURLConnection.HTTP_MOVED_PERM
                        || status == HttpURLConnection.HTTP_MOVED_TEMP
                        || status == 307
                        || status == 308) {
                    String location = connection.getHeaderField("Location");
                    connection.disconnect();
                    connection = null;
                    if (location == null || location.isBlank()) return null;
                    currentUrl = resolveUrl(location, currentUrl);
                    if (currentUrl == null) return null;
                    continue;
                }

                if (status < 200 || status >= 400) return null;

                String contentType = connection.getContentType();
                if (contentType != null
                        && !contentType.contains("text/html")
                        && !contentType.contains("application/xhtml")) {
                    return null;
                }

                // H-02: detect charset from Content-Type before reading stream
                String charset = "UTF-8";
                if (contentType != null) {
                    Matcher m = CHARSET_PATTERN.matcher(contentType);
                    if (m.find()) charset = m.group(1).trim();
                }

                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), charset)
                );
                StringBuilder body = new StringBuilder();
                char[] buffer = new char[8192];
                int charsRead;
                int totalRead = 0;
                while ((charsRead = reader.read(buffer)) != -1) {
                    body.append(buffer, 0, charsRead);
                    totalRead += charsRead;
                    if (totalRead >= MAX_BODY_SIZE) break;
                }
                reader.close();
                return body.toString();
            }

            return null; // exceeded redirect limit

        } catch (IOException e) {
            return null;
        } catch (IllegalArgumentException e) {
            return null;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    // H-01: primary method returning URLs + anchor text pairs
    public List<LinkWithText> extractLinksWithText(String html, String baseUrl) {
        List<LinkWithText> results = new ArrayList<>();
        if (html == null || html.isBlank()) return results;

        Matcher matcher = ANCHOR_PATTERN.matcher(html);
        while (matcher.find()) {
            String href       = matcher.group(1).strip();
            String rawAnchor  = matcher.group(2);
            String anchorText = rawAnchor == null ? "" :
                decodeEntities(rawAnchor.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").strip());

            if (href.isEmpty() || href.equals("#")) continue;

            int fragmentIdx = href.indexOf('#');
            if (fragmentIdx == 0) continue;
            if (fragmentIdx > 0) href = href.substring(0, fragmentIdx);
            if (href.isEmpty()) continue;

            String hrefLower = href.toLowerCase();
            if (hrefLower.startsWith("javascript:") || hrefLower.startsWith("mailto:")
                    || hrefLower.startsWith("tel:")  || hrefLower.startsWith("data:")
                    || hrefLower.startsWith("ftp:")  || hrefLower.startsWith("irc:")) {
                continue;
            }

            if (isBinaryExtension(hrefLower)) continue;

            String absoluteUrl = resolveUrl(href, baseUrl);
            if (absoluteUrl != null && !absoluteUrl.isBlank()) {
                results.add(new LinkWithText(absoluteUrl, anchorText));
            }
        }
        return results;
    }

    // backward-compatible wrapper
    public List<String> extractLinks(String html, String baseUrl) {
        List<LinkWithText> pairs = extractLinksWithText(html, baseUrl);
        List<String> urls = new ArrayList<>(pairs.size());
        for (LinkWithText p : pairs) urls.add(p.url);
        return urls;
    }

    public String extractTitle(String html) {
        if (html == null || html.isBlank()) return "[No Title]";
        Matcher matcher = TITLE_PATTERN.matcher(html);
        if (matcher.find()) {
            String title = matcher.group(1).strip().replaceAll("\\s+", " ");
            title = decodeEntities(title);
            return title.isEmpty() ? "[No Title]" : title;
        }
        return "[No Title]";
    }

    public String extractPageText(String html) {
        if (html == null || html.isBlank()) return "";
        String cleaned = html.replaceAll("(?is)<script[^>]*>.*?</script>", "");
        cleaned = cleaned.replaceAll("(?is)<style[^>]*>.*?</style>", "");
        cleaned = cleaned.replaceAll("<[^>]+>", " ");
        cleaned = decodeEntities(cleaned);
        cleaned = cleaned.replaceAll("\\s+", " ").strip();
        if (cleaned.length() > 10240) cleaned = cleaned.substring(0, 10240);
        return cleaned;
    }

    // H-03: named + decimal + hex entity decoding
    private static String decodeEntities(String text) {
        text = text.replace("&amp;",  "&")
                   .replace("&lt;",   "<")
                   .replace("&gt;",   ">")
                   .replace("&quot;", "\"")
                   .replace("&apos;", "'")
                   .replace("&nbsp;", " ")
                   .replace("&#39;",  "'")
                   .replace("&#x27;", "'")
                   .replace("&#34;",  "\"");

        // decimal numeric entities: &#8212; → em-dash
        Matcher dec = ENTITY_DECIMAL.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (dec.find()) {
            int codePoint = Integer.parseInt(dec.group(1));
            dec.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) codePoint)));
        }
        dec.appendTail(sb);
        text = sb.toString();

        // hex numeric entities: &#x2014; → em-dash
        Matcher hex = ENTITY_HEX.matcher(text);
        sb = new StringBuffer();
        while (hex.find()) {
            int codePoint = Integer.parseInt(hex.group(1), 16);
            hex.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf((char) codePoint)));
        }
        hex.appendTail(sb);
        return sb.toString();
    }

    private static boolean isBinaryExtension(String href) {
        int qIdx = href.indexOf('?');
        String pathOnly = qIdx >= 0 ? href.substring(0, qIdx) : href;
        return pathOnly.matches(
            ".*\\.(jpg|jpeg|png|gif|svg|webp|ico|bmp|pdf|doc|docx|xls|xlsx" +
            "|ppt|pptx|zip|rar|gz|tar|mp3|mp4|avi|mov|wmv|css|js" +
            "|woff|woff2|ttf|eot|xml|rss|atom)$"
        );
    }

    private String resolveUrl(String href, String baseUrl) {
        try {
            URI base     = new URI(baseUrl);
            URI resolved = base.resolve(new URI(href.replace(" ", "%20")));
            String scheme = resolved.getScheme();
            if (scheme == null) return null;
            scheme = scheme.toLowerCase();
            if (!scheme.equals("http") && !scheme.equals("https")) return null;
            return resolved.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
